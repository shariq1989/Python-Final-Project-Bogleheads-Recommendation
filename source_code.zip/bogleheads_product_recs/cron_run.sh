#!/bin/sh
cd /home/shariq1989/Documents/Harvard/Python/Project/bogleheads_product_recs/
python3 main.py
